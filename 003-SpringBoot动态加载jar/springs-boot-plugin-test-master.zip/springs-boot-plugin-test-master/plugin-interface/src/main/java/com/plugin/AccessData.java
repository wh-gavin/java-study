package com.plugin;

/**
 * @Description
 * @Date 2023/2/14 17:38
 * @Author qinfei
 **/
public class AccessData {

    private String appKey; // 创建用户ID
    private String appSecret; // 对用户ID+jar包记录ID+业务表ID进行MD5加密
    private String data; // 数据
}

