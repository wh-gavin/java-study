package com.plugin;

/**
 * @Description
 * @Date 2023/2/14 17:18
 * @Author qinfei
 **/
public interface CustomAccessInterface {

    Result customAccess(AccessData accessData);
}
