package com.plugin;

/**
 * @Description
 * @Date 2023/2/14 17:18
 * @Author qinfei
 **/
public class Result {

    /** 是否成功 */
    public boolean success;
    /** 消息 */
    public String message;
    /** 返回错误码值 */
    public String code;
}
