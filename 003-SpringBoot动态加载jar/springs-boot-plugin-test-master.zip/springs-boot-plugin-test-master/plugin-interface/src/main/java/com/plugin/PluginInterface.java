package com.plugin;

public interface PluginInterface {
    String sayHello(String name);
}
